PROJECT EXODUS — DAY ONE SIEGES
Minecraft 1.21.1 NeoForge

CHANGED:
- overrides/config/hordes-common.toml: spawnFirstDay = true
  The first natural horde can now be scheduled on game day 0. Existing 7-day recurrence is retained.

REQUIRED ADDITIONAL MOD FOR BLOCK BREAKING:
Zombie Break & Build 1.7.0 for 1.21.1 NeoForge
https://modrinth.com/mod/zombies-break-and-build/version/1.21.1-1.7.0-neoforge
Install it in the launcher separately. The mod JAR is NOT bundled in this export.

After launching once, review config/zombies-break-build.toml (or use /zbb config),
and enable block breaking for vanilla zombie-type mobs. The mod does not have
a day-gated progression mechanic described in its documentation; it can act
from the moment installed and enabled. Its defaults and breaking eligibility
must be confirmed in-game.

IMPORTANT: 'spawnFirstDay' does not itself give zombies mining ability.
Take a world backup first. Test on a fresh world and check mobGriefing.
Not tested in a running game.
