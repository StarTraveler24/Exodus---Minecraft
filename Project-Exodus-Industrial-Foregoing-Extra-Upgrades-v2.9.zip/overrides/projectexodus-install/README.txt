PROJECT EXODUS - DIMENSIONAL ORES & NETHER INFECTION 0.2

Install the separate ProjectExodus-Dimensions-v0.2.zip file into your WORLD/datapacks folder.
Restart the world (worldgen changes require reload); use /datapack list to verify.

Nether:
- Spore biome tag now includes all five vanilla Nether biomes; the existing Spore config points to it.
- Selected Spore entity types get continuously refreshed Fire Resistance only while in the Nether.
- Fire Resistance blocks vanilla lava/fire damage, but does not ensure lava swimming or prevent modded non-fire damage.
- May linger up to two seconds after exiting the Nether.
- Two extra uneven ore deposits: netherrack-hosted Nether Gold and Nether Quartz; old chunks do not regenerate.

Other dimensions:
- Original Overworld ore generation left untouched to avoid unsafe registry overrides.
- Moon/Mars custom ore placement intentionally NOT added because Cosmonautics biome IDs/planet host block IDs are unverified in this CurseForge export.
- No invented ore items or Mekanism ore features were added.
- This patch has not been startup-tested with actual mod JARs.

Keep your world backed up and inspect logs for worldgen feature cycle issues.
