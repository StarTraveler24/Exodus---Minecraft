# Project Exodus — Planetary Exploration v0.4
Minecraft 1.21.1 / NeoForge 21.1.264

## Actual installed additions (CurseForge-managed)
- Create Cosmonautics Expansion 1.0.0 (project 1640364, file 8582021): adds Mars and Mars plains, frostlands, underground caves.
- Create Cosmonautics: Structures+ 1.1 (project 1671959, file 8812608): adds 10 exploration structures to the Moon.

The mods are referenced in manifest.json. CurseForge downloads the JARs when importing the profile. JARs are not embedded in this ZIP.

## Planetary expansion roadmap — designs, not installed features
Moon: scattered derelict research stations, subterranean research bunkers, scarce water-ice reserves, contaminated hives, scarce high-value rare minerals.
Mars: kilometer-scale geological canyon regions, ruined cities, underground fungal ecosystems, collapsed mines, living hive caverns, dust storms, and hostile planet-specific Spore variants.
Asteroid belt: automated mining sites and abandoned shipwrecks.
Future Europa: ice and subsurface oceans; future Titan: hydrocarbon chemistry and hostile subsurface settlements.

These require additional worldgen data / custom structures / bespoke mod code; the extra planets are not bundled.
Cosmonautics supports data-driven celestial definitions, but defining planets alone does not generate a playable dimension.

## Important testing
- Back up the world before import.
- Import as new CurseForge profile; check that both addons were downloaded.
- Create a fresh test world first and verify travel and structures. New structures usually require new chunks.
- Test whether existing zombie-only biome modifiers suppress or affect the two addons' spawns.
- The two addons have not been compatibility-tested against every mod in this large pack.
- This archive preserves the source modpack's prior overrides and setup files. If a separate datapack was previously installed into your world's datapacks folder, keep it there.
