PROJECT EXODUS — MARS GEOLOGY FOUNDATION v0.5
Minecraft 1.21.1 • NeoForge

WHAT THIS RELEASE CONTAINS
- 3 datapack-based Mars ore distributions (iron clusters, copper belts, redstone seams).
- Configurable Mars biome tag and Mars ore-host-rock tag.
- Provided as a separate world datapack next to the updated CurseForge profile.
- Existing pack files and settings preserved.

REQUIRED BEFORE MARS ORES WILL GENERATE
The Mars addon JAR is not included in the CurseForge export. Consequently its *actual* registered biome IDs and stone block IDs have not been verified. The included Mars biome tag is INTENTIONALLY EMPTY, preventing accidental generation in other dimensions. Its ore-host-rock tag contains vanilla stone, deepslate and tuff as safe defaults, which might not occur on Mars.

1. Open the actual running modpack and visit Mars. Press F3 and read the biome identifier, e.g. some_mod:some_mars_biome. Record distinct biomes from plains, frostlands and caves.
2. With advanced tooltips F3+H, check the registered block IDs of natural Mars rock (using an inspection mod such as Jade if necessary).
3. Open the standalone Mars datapack ZIP, then edit data/projectexodus/tags/worldgen/biome/mars_regions.json and put the confirmed biome IDs in its values array.
4. Edit data/projectexodus/tags/block/mars_ore_replaceables.json and append confirmed natural Mars host-rock block IDs.
5. Put the resulting standalone datapack ZIP in <world>/datapacks and reload or reopen the world. DO NOT install both this standalone datapack and an unpacked duplicate into the same world's datapack folder.
6. Explore newly generated Mars chunks. Test with /datapack list and examine mining. Ores will not retroactively generate in old chunks.

IMPORTANT: This is the initial GEOLOGY foundation, not a finished custom Mars dimension. It does not yet add caves, abandoned laboratories, infection hive structures, or new textures. These require registered terrain IDs, actual structure templates and/or custom mod code.

A CurseForge export references downloadable mods in its manifest. It does not contain the installed JARs and has not been game-tested here.
