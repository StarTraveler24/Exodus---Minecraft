Adds 26 species-specific genome sample purchases and 6 lab supply trades using emeralds as Exodus Credits.
Samples have PatientZero custom_data with species IDs, not blank genome items.
The game should be tested to ensure the ItemStack data component survives FTB Quests rewards and PatientZero accepts the resulting sample.
If samples don't unlock genetics, a dedicated reward-handler addon will be necessary. This pack is not in-game tested.
