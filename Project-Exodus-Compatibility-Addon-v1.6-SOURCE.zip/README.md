# Project Exodus compatibility addon v1.6 (source)
Minecraft 1.21.1 / NeoForge 21.1.264 / Java 21

This is **source code only**, not a compiled or game-tested mod.

## Build with GitHub Actions
1. Create a new GitHub repository and upload the **contents** of this ZIP (including `.github/workflows/build.yml`).
2. Open the Actions tab and select **Build Project Exodus compatibility addon** → Run workflow.
3. If the build succeeds, download `project-exodus-compat-jar` artifact, extract it, and put its JAR into the Project Exodus `mods` folder.
4. If the build fails, review the compiler output; do not install the source ZIP as a Minecraft mod.

Alternatively install Gradle 8.14 and JDK 21, then run `gradle build`.

## Current functionality (unverified)
- Protects registered Spore entities from drowning and suffocation/freezing in rocketnautics, rocketnautics_addon and custom belt dimensions.
- Refreshes Spore air in these dimensions.
- Cancels fire/lava/hot floor damage to Spore entities in the Nether and supplies Fire Resistance.
- Does not protect players. Does not grant immunity to weapons.

## Remaining integration
Mod-specific vacuum damage identifiers and precise Cosmonautics spacecraft transfers still need gameplay testing. This is not a complete natural Mars hive/asteroid solution.
