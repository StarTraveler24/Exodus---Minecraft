PROJECT EXODUS — TEST BUILD 0.1 (Minecraft 1.21.1 NeoForge)

What this actually changes:
1. A loadable world datapack resets Air to 300 every game tick for tagged
   Spore infected mobs and vanilla zombies. Intended to stop Cosmonautics
   atmosphere drowning, without shielding them from swords, guns or explosions.
2. The updated Spore spawn config adds projectexodus:infected_planets to its
   allowed BIOME TAGS. The tag starts EMPTY on purpose: no exact lunar/Martian
   biome registry IDs were included in this CurseForge export. This is NOT YET
   proof that infected creatures spawn on the Moon or Mars automatically.
3. Retains all 79 CurseForge-managed mod entries and other exported settings.

INSTALLATION — OPTION A: EXISTING PROFILE (safer)
1. BACK UP THE INSTANCE AND TEST WORLD. Close Minecraft.
2. Copy the provided overrides/config/spore-startup.toml to your existing
   instance's config/spore-startup.toml (replacing its original).
3. Copy ProjectExodus-Infection-Datapack.zip to:
   saves/<your world>/datapacks/
   [For a new world, choose datapacks from world creation instead.]
4. Start the world and run /reload then /datapack list enabled.
5. In a creative testing copy, summon an infected mob in the Moon and observe
   whether it survives. The oxygen workaround was suggested by a Cosmonautics
   contributor, but this specific combination has NOT been game-tested here.
6. For planet spawning, first find the true BIOME IDs on the Moon and Mars
   using Minecraft debug / biome tools. Edit
   data/projectexodus/tags/worldgen/biome/infected_planets.json
   to add the real biome names under values; rezip the datapack, and /reload.
   The Spore custom spawn system may require additional code depending on its
   biome-tag matching behavior.

INSTALLATION — OPTION B: CURSEFORGE
Import Project-Exodus-Patched-Profile.zip as a new profile. It includes the
updated config and a noninstalled copy of the datapack and instructions in
its overrides/project_exodus_setup/ folder. Copy the datapack into each world.

NOT DONE YET:
- Fully automatic spawning/territory growth on every planet (requires actual
  biome IDs and further compatibility testing).
- Immunity to all possible planet hazards, e.g. temperature and radiation.
- Custom Martian caves, ruins, new planets, and disease targeting Spore mobs.
- Any compiled Java compatibility addon or tested modpack launch.
- Installing Mars Expansion (not listed in your uploaded manifest).

If a problem occurs, remove the datapack and restore your original Spore config.

Sources: github.com/CosmonauticsTeam/Create-Cosmonautics/discussions/74
         github.com/CosmonauticsTeam/Create-Cosmonautics/wiki
