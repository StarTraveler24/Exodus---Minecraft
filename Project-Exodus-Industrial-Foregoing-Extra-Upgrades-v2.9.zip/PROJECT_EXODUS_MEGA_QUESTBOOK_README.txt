Project Exodus Mega Questbook v2.2
{'sell': 136, 'buy': 171, 'progress': 120}
Emeralds are physical credits. Shops consume credits; sales consume items. Existing quests preserved.
Test in a NEW world and backup existing FTB quest data. FTB SNBT parsing and quest repeat mechanics not tested in-game.
Many progression tasks are checkmark milestones (manual completion), not event-detected.
Some bulk prices and item availability will need in-game economic balancing.
