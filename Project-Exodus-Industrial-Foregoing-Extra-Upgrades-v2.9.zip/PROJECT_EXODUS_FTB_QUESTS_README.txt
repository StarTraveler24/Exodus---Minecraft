FTB Quests starter campaign (20 quests, five chapters).
The CurseForge manifest installs FTB Quests 2101.1.36 for Minecraft 1.21.1 NeoForge.
The new book files are in overrides/config/ftbquests/quests/.
Existing installations: back up config/ftbquests/quests before replacing it.
Some later exploration quests are provisional, especially the Mars dimension ID; review in-game and correct if necessary.
Open with /ftbquests open_book; edit with /ftbquests editing_mode true.
This is not gameplay-tested.
