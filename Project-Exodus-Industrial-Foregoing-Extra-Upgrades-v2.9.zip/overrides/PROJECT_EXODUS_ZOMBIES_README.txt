PROJECT EXODUS - Zombie-Only survival

1. Your CurseForge profile will install Zombie Break & Build v1.6.0 (NeoForge 1.21.1) through its manifest. Minecraft 1.21.1 only.
2. This profile includes the Zombie-Only datapack UNPACKED in project-exodus-datapack-unpacked/. Copy the CONTENT of that directory into a ZIP, or use separate ProjectExodus-Zombie-Only-Datapack.zip.
3. Install the datapack in EACH existing world's saves/<world>/datapacks folder before loading, or add it during world creation. Do NOT put it in mods/.
4. Without the datapack installed, hostile spawn restrictions and loot changes DO NOT take effect.
5. Spawning is removed through NeoForge biome modifiers from Overworld, Nether and End tagged biomes. Spawners, scripted summons, raids, structures and special modded dimensions are NOT blocked by this datapack.
6. Zombie loot is rebalanced to include missing resources (gunpowder, string, blaze rods, ender pearls, wither skulls, shulker shells etc). Drowned tridents and copper-related special drops are replaced by shared zombie loot; check mod progression as needed.
7. The Hordes and Spore creatures remain, and bosses are unaffected. Modded hostile entities OTHER THAN Spore may still spawn.
8. Backup worlds first; do a test in a disposable world.
9. Zombie Break & Build v1.6.0 uses an older configuration than 1.7.0; upgrade separately if desired.
