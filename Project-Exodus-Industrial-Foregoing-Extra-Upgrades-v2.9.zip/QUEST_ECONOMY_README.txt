Project Exodus v2.1 — FTB Quests economy and chemical guide.

New chapters: Exodus Contracts, Supply Exchange, Chemical & Fluid Handbook.
Economy uses regular emeralds as Exodus Credits, not a separate virtual wallet.
Contracts and shops use can_repeat and consume_items. This is an UNTESTED FTB Quests SNBT implementation.
Install/import as a separate profile. Existing worlds may already have generated questbook data in world/serverconfig or ftbquests; back it up before replacing.
No mods or crafting recipes were changed, only quest content.
Notes: balance can be bypassed with normal villager emerald trades; consider further economy restrictions.
Do not stack competing questpack SNBT versions.
