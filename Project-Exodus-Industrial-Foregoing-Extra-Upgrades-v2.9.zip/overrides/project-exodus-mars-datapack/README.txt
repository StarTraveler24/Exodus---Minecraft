Standalone world datapack is distributed as ProjectExodus-Mars-Geology-v0.5.zip alongside this profile. Install it into your WORLD/datapacks after filling registered IDs.
