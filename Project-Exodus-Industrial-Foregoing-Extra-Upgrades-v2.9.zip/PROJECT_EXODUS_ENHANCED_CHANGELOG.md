# Project Exodus — Enhanced Gameplay Configuration

This is an edited version of the previously patched CurseForge profile, not a tested game build. Back up your instance and world. Import as a SEPARATE profile, or copy the edited configuration files into your current instance. Server and client configuration may need matching changes.

## Changes

- `overrides/config/createaddition-common.toml`: `tesla_coil_hurt_range` **3 → 4**
- `overrides/config/createaddition-common.toml`: `tesla_coil_hurt_mob` **3 → 5**
- `overrides/config/createaddition-common.toml`: `tesla_coil_hurt_energy_required` **1000 → 1800**
- `overrides/config/createaddition-common.toml`: `tesla_coil_fire_cooldown` **20 → 16**
- `overrides/config/createaddition-common.toml`: `tesla_coil_capacity` **40000 → 60000**
- `overrides/config/hordes-common.toml`: `spawnAmount` **15 → 18**
- `overrides/config/hordes-common.toml`: `hordeSpawnMultiplier` **1.05 → 1.07**
- `overrides/config/hordes-common.toml`: `hordeSpawnDays` **10 → 7**
- `overrides/config/hordes-common.toml`: `hordeSpawnMax` **160 → 120**
- `overrides/config/hordes-common.toml`: `hordePathingInterval` **25 → 35**
- `overrides/config/hordes-common.toml`: `hordeSpawnDistance` **75.0 → 70.0**
- `overrides/config/mekmissilesconfig.properties`: `MISSILE_MAX_FORCED_CHUNKS` **512 → 128**
- `overrides/config/mekmissilesconfig.properties`: `MISSILE_RADAR_SCAN_INTERVAL` **20 → 12**
- `overrides/config/mekmissilesconfig.properties`: `MISSILE_RADAR_ENERGY_PER_SCAN` **200 → 260**
- `overrides/config/mekmissilesconfig.properties`: `MISSILE_SIREN_ALERT_RADIUS` **256 → 320**
- `overrides/config/patientzero-common.toml`: `transmissionRadius` **5.0 → 6.0**
- `overrides/config/patientzero-common.toml`: `baseTransmissionChance` **0.08 → 0.1**
- `overrides/config/patientzero-common.toml`: `geneCapacity` **10 → 12**
- `overrides/config/patientzero-common.toml`: `vaccineDays` **14 → 10**
- `overrides/config/patientzero-common.toml`: `sequencerTime` **600 → 500**

## Design notes

- Zombie hordes come every 7 in-game days rather than 10, have stronger waves, and are capped at 120 simultaneous event mobs to reduce worst-case lag. Spore adds its own enemies on top.
- PatientZero airborne diseases spread slightly farther and more readily; sequencing is faster, vaccine protection is shorter, and virus gene capacity is increased. These settings do NOT prove that Spore mobs are susceptible.
- Create Crafts & Additions Tesla coils hit farther and harder but consume more energy per attack, rewarding power infrastructure.
- Mekanism missile radar checks more often and has a larger siren radius, with higher scan energy consumption. Maximum simultaneously force-loaded missile chunks is reduced for performance; this may limit large salvos.
- Existing Cosmonautics infection datapack is preserved. It is NOT a complete verified planetary infection system.

## Not changed

- Cosmonautics rocket physics, Create Big Cannons damage, and world generation were left alone without verified cross-mod settings.
- No custom planets, structures, AI or disease cross-mod integration is installed by this pack.

## Validation

- All modified TOML files were parsed successfully.
- All modified settings were present in the original configuration.
- In-game startup and balance have NOT been tested.
