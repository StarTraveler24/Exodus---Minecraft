Project Exodus 1.4 CurseForge export with the GitHub Actions compiled project-exodus-compat-0.1.0.jar included in overrides/mods.
The addon's GitHub build succeeded, but the entire modpack has NOT been launched or tested for gameplay compatibility.
Planetary worldgen and asteroid datapacks still require world-level installation as documented in the profile.
